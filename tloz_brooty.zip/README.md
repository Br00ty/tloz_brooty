# The Legend of Zelda Map Tracker 

This is a map tracker for the AP build of TLoZ Randomizer!

This pack features autotracking when connected to the AP server.

## Installation

Just download the lastest [build](https://github.com/Br00ty/tloz_brooty/releases/latest) and put it in your poptracker/packs folder.

## More Info

Check out PopTrackers Documentation on packs [here](https://github.com/black-sliver/PopTracker/blob/master/doc/PACKS.md)

Still having trouble realizing your pack and looking for help or just want more information about everything PopTracker? Check out the ['Unofficial' PopTracker Discord Server](https://discord.com/invite/gwThqMCPgK)!

## License

*flashes Link's drivers license*
